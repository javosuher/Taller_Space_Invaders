package com.me.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public class GameScreen implements Screen{ // Implementa la interfaz de Screen, es decir, se comportara con las caracteristicas de una pantalla
	// sus funciones se llaman automaticamente cuando ocurre el evento al que estan asociadas (renderizar,
	//reescalar, pausar, resumir...) menos con dispose, para liberar los recursos hay que llamar a dispose manualmente
	
	private ejercicio2 invaders;
	private Texture TexturaFondo, texturaShip; // Una Texture es una clase que envuelve una textura estandar de OpenGL, se utiliza para imagenes simples.
	private SpriteBatch batch; // "Grupo de Sprites (imagenes)" nos permite dibujar rectagulos como referencias a texturas, es necesario para mostrar todo por pantalla
	private ship nave; // Nave del juego.

	public GameScreen(ejercicio2 invaders) {
		this.invaders = invaders;
		
		//Creamos las texturas, primero el fondo del juego.
		TexturaFondo = new Texture("data/Background.png"); // Asociamos la textura con la imagen correspondiente
		TexturaFondo.setFilter(TextureFilter.Linear, TextureFilter.Linear); // con setFilter controlamos la forma en la que la imagen se 
		//reescala, le añadimos el parametro TextureFilter.Linear en ambos casos, para que este reescalado sea lineal.
		
		// Creamos la nave
		texturaShip = new Texture("data/ship.png");
		texturaShip.setFilter(TextureFilter.Linear, TextureFilter.Linear);
		nave = new ship(new Vector2(10,10), texturaShip.getWidth(), texturaShip.getHeight()); 
		//Creamos la nave en la posición de la panatalla que queremos(10, 10), y ancho y altura de la imagen.
		
		batch = new SpriteBatch();
	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0, 1); //Gdx es una clase con la que podemos acceder a variables que hacen referencia a todos los subsitemas, como son graficos, audio, ficheros, entrada y aplicaciones
		// gl es una variable de tipo GL, nos permite acceder a metodos de GL10, GL11 y GL20
		//En este caso glClearColor es un bucle (game loop) que establecera el fondo de la pantalla negro (0,0,0) con transparencia 1
		Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT); // Despues de la funcion anterior es necesario ejecutar esta, para que se lleve a cabo

		//Hacemos que se actualizen los parametros de la nave en la pantalla.
		nave.update(); // Devuelve true si se ha disparado.
		
		batch.begin(); // Aqui por fin comenzamos el renderizado
		//Dibujamos el fondo
		batch.draw(TexturaFondo, 0, 0, TexturaFondo.getWidth(), TexturaFondo.getHeight()); //La dibujamos en la esquina inferior derecha, tamaño natural
		//Dibujamos nuestra nave
		batch.draw(texturaShip, nave.getPosicion().x, nave.getPosicion().y, nave.getAnchura(), nave.getAltura());
		batch.end();
		// Terminamos el renderizado.
	}

	@Override
	public void resize(int width, int height) {

	}
	@Override
	public void show() {
		// TODO Auto-generated method stub

	}
	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}
	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}
	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}
	@Override
	public void dispose() {
		//batch.dispose();
	}
}