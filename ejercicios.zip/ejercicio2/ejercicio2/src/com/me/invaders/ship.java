package com.me.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class ship {
	private static final float SPEED = 20; // Velocidad de movimiento de la nave.
	private static final float MARGEN_IZQUIERDO = 10; // Margen izquierdo que no puede pasar la nave.
	private static final float MARGEN_DERECHO = 936; // Margen derecho que no puede pasar la nave.
		
	private Vector2 posicion;
	private float anchura, altura;
	private Rectangle bordes;
		
	public ship(Vector2 posicion, float anchura, float altura) {
		this.posicion = posicion;
		this.anchura = anchura;
		this.altura = altura;
		bordes = new Rectangle(posicion.x, posicion.y, anchura, altura);
	}

	public void update () { // Funcion que se ejecuta en Render de GameScren, y son las opciones que puede tener la nave
		boolean disparo = false;
		if(Gdx.input.isKeyPressed(Keys.RIGHT) && NoChoqueBordeDerecha()) {
			// Make: Hacemos que se desplace la nave hacia la derecha. Pista - Puedes usar SPEED
				
		}
			
		if(Gdx.input.isKeyPressed(Keys.LEFT) && NoChoqueBordeIzquierda()) {
			// Make: Igual que el anterior pero para la izquierda
				
		}
			
		// Actualizamos los bordes (la anchura y altura ya se definen en el constructor de Entidad
		bordes.x = posicion.x;
		bordes.y = posicion.y;
	}
	
	private boolean NoChoqueBordeDerecha() { // Permite que la nave no siga avanzando y salirse de la pantalla por la derecha.
		// Make: Ponerle a la nave un limite para que no se salga de la pantalla al moverla.
	}
	private boolean NoChoqueBordeIzquierda() { // Permite que la nave no siga avanzando y salirse de la pantalla por la izquierda.
		// Make: Ponerle a la nave un limite para que no se salga de la pantalla al moverla.
	}
		
	// Getters -----------------------------------

	public static float getSpeed() {
		return SPEED;
	}

	public Vector2 getPosicion() {
		return posicion;
	}

	public float getAnchura() {
		return anchura;
	}

	public float getAltura() {
		return altura;
	}

	public Rectangle getBordes() {
		return bordes;
	}
}
